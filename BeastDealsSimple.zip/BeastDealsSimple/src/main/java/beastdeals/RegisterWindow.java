package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RegisterWindow extends JFrame {
    private JTextField userField;
    private JPasswordField passField, confField;

    public RegisterWindow() {
        setTitle("Register");
        setSize(420, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(35, 39, 42));

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(35, 39, 42));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 38, 20, 38));
        mainPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel heading = new JLabel("Create Account");
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setForeground(new Color(255, 139, 44));
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);

        mainPanel.add(heading);
        mainPanel.add(Box.createVerticalStrut(15));

        JLabel userLbl = new JLabel("Username:");
        userLbl.setForeground(Color.WHITE);
        userLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(userLbl);

        mainPanel.add(Box.createVerticalStrut(2));
        userField = new JTextField();
        styleField(userField);
        mainPanel.add(centerPanel(userField));

        mainPanel.add(Box.createVerticalStrut(10));
        JLabel passLbl = new JLabel("Password:");
        passLbl.setForeground(Color.WHITE);
        passLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(passLbl);

        mainPanel.add(Box.createVerticalStrut(2));
        passField = new JPasswordField();
        styleField(passField);
        mainPanel.add(centerPanel(passField));

        mainPanel.add(Box.createVerticalStrut(10));
        JLabel confLbl = new JLabel("Confirm Password:");
        confLbl.setForeground(Color.WHITE);
        confLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(confLbl);

        mainPanel.add(Box.createVerticalStrut(2));
        confField = new JPasswordField();
        styleField(confField);
        mainPanel.add(centerPanel(confField));

        mainPanel.add(Box.createVerticalStrut(18));

        // Register Button
        JButton registerBtn = new JButton();
        ImageIcon regIcon = new ImageIcon("icons/register_b.png");
        Image regImg = regIcon.getImage().getScaledInstance(182, 48, Image.SCALE_SMOOTH);
        registerBtn.setIcon(new ImageIcon(regImg));
        registerBtn.setBorder(null);
        registerBtn.setContentAreaFilled(false);
        registerBtn.setFocusPainted(false);
        registerBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        registerBtn.addActionListener(e -> handleRegister());
        mainPanel.add(registerBtn);

        wrapper.add(mainPanel);
        setContentPane(wrapper);
    }

    private void styleField(JTextField field) {
        field.setBackground(new Color(60, 60, 70));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        field.setFont(new Font("Arial", Font.PLAIN, 17));
        field.setMaximumSize(new Dimension(230, 38));
        field.setPreferredSize(new Dimension(230, 38));
        field.setHorizontalAlignment(JTextField.CENTER);
    }

    private JPanel centerPanel(JComponent c) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        p.setBackground(new Color(35, 39, 42));
        p.add(c);
        return p;
    }

    private void handleRegister() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword()).trim();
        String conf = new String(confField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty() || conf.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!");
            return;
        }
        if (!password.equals(conf)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match!");
            return;
        }
        if (password.length() < 4) {
            JOptionPane.showMessageDialog(this, "Password too short!");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String check = "SELECT id FROM users WHERE username=?";
            PreparedStatement checkStmt = conn.prepareStatement(check);
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Username already exists!");
                return;
            }
            
            String sql = "INSERT INTO users (username, password_hash) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password); 
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Registration successful!");
            dispose();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error registering.");
        }
    }
}
