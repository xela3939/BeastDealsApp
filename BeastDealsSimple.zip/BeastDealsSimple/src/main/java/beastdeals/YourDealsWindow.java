package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class YourDealsWindow extends JFrame {
    private JPanel dealsPanel;
    private String username;

    public YourDealsWindow(String username) {
        this.username = username;
        setTitle("Your Deals");
        setSize(880, 620);
        setLocationRelativeTo(null);

        Color cardBg = new Color(26, 27, 30);
        Color darkBg = new Color(35, 39, 42);
        Color orange = new Color(255, 139, 44);
        Color borderGray = new Color(60, 60, 70);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(darkBg);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(22, 0, 22, 0));

        JLabel titleLabel = new JLabel("Your Deals");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(24));

        dealsPanel = new JPanel();
        dealsPanel.setLayout(new BoxLayout(dealsPanel, BoxLayout.Y_AXIS));
        dealsPanel.setBackground(darkBg);

        JScrollPane scrollPane = new JScrollPane(dealsPanel);
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(18);
        scrollPane.setPreferredSize(new Dimension(830, 480));

        mainPanel.add(scrollPane);
        add(mainPanel);

        loadYourDeals();
    }

    private void loadYourDeals() {
        dealsPanel.removeAll();
        ArrayList<Integer> dealIds = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id FROM deals WHERE username=? ORDER BY id DESC";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                dealIds.add(rs.getInt("id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (dealIds.isEmpty()) {
            JLabel noDeals = new JLabel("You haven't posted any deals yet.");
            noDeals.setFont(new Font("Arial", Font.ITALIC, 18));
            noDeals.setForeground(Color.LIGHT_GRAY);
            noDeals.setAlignmentX(Component.CENTER_ALIGNMENT);
            dealsPanel.add(Box.createVerticalStrut(32));
            dealsPanel.add(noDeals);
        } else {
            for (int dealId : dealIds) {
                JPanel dealPanel = getDealPanel(dealId);
                if (dealPanel != null) {
                    dealsPanel.add(dealPanel);
                    dealsPanel.add(Box.createVerticalStrut(16));
                }
            }
        }
        dealsPanel.revalidate();
        dealsPanel.repaint();
    }

    private JPanel getDealPanel(int dealId) {
        Color cardBg = new Color(26, 27, 30);
        Color borderGray = new Color(60, 60, 70);
        Color orange = new Color(255, 139, 44);

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, title, price, image1, description, expiry_date, link FROM deals WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, dealId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String title = rs.getString("title");
                String price = rs.getString("price");
                String imageFile = rs.getString("image1");
                String description = rs.getString("description");
                String expires = rs.getString("expiry_date");
                String link = rs.getString("link");

                JPanel dealCard = new JPanel();
                dealCard.setLayout(new BoxLayout(dealCard, BoxLayout.X_AXIS));
                dealCard.setBackground(cardBg);
                dealCard.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(borderGray, 1, true),
                        BorderFactory.createEmptyBorder(12, 16, 12, 16)
                ));
                dealCard.setMaximumSize(new Dimension(800, 120));
                dealCard.setAlignmentX(Component.LEFT_ALIGNMENT);

                // Delete button (left, big)
                JButton deleteBtn = new JButton();
                ImageIcon binIcon = new ImageIcon("icons/recicle_bin.png");
                Image binImg = binIcon.getImage().getScaledInstance(38, 38, Image.SCALE_SMOOTH);
                deleteBtn.setIcon(new ImageIcon(binImg));
                deleteBtn.setToolTipText("Delete this deal");
                deleteBtn.setBackground(new Color(45, 47, 52));
                deleteBtn.setFocusPainted(false);
                deleteBtn.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
                deleteBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                deleteBtn.setPreferredSize(new Dimension(54, 54));
                deleteBtn.setMaximumSize(new Dimension(54, 54));
                deleteBtn.addActionListener(e -> {
                    int confirm = JOptionPane.showConfirmDialog(this,
                            "Are you sure you want to delete this deal?",
                            "Delete Deal", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        deleteDeal(dealId);
                        loadYourDeals();
                    }
                });

                dealCard.add(deleteBtn);
                dealCard.add(Box.createHorizontalStrut(22));

                // Deal image
                JLabel imageLabel;
                if (imageFile != null && !imageFile.isEmpty()) {
                    String imagePath = "images/" + imageFile;
                    ImageIcon icon = new ImageIcon(imagePath);
                    Image img = icon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
                    imageLabel = new JLabel(new ImageIcon(img));
                } else {
                    imageLabel = new JLabel("No Image");
                    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                    imageLabel.setPreferredSize(new Dimension(80, 80));
                }
                dealCard.add(imageLabel);
                dealCard.add(Box.createHorizontalStrut(22));

                // Info panel
                JPanel infoPanel = new JPanel();
                infoPanel.setOpaque(false);
                infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
                infoPanel.setMaximumSize(new Dimension(420, 90));

                JLabel titleLabel = new JLabel(title);
                titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
                titleLabel.setForeground(Color.WHITE);
                infoPanel.add(titleLabel);

                JLabel priceLabel = new JLabel("£" + price);
                priceLabel.setFont(new Font("Arial", Font.BOLD, 16));
                priceLabel.setForeground(orange);
                infoPanel.add(Box.createVerticalStrut(4));
                infoPanel.add(priceLabel);

                dealCard.add(infoPanel);
                dealCard.add(Box.createHorizontalGlue());

                // Go to deal button
                JButton gotoBtn = new JButton("Go to Deal");
                gotoBtn.setBackground(orange);
                gotoBtn.setForeground(Color.WHITE);
                gotoBtn.setFocusPainted(false);
                gotoBtn.setFont(new Font("Arial", Font.BOLD, 14));
                gotoBtn.setBorder(BorderFactory.createEmptyBorder(10, 26, 10, 26));
                gotoBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                gotoBtn.setAlignmentY(Component.CENTER_ALIGNMENT);

                gotoBtn.addActionListener(e -> {
                    new DealDetailWindow(title, description, price, expires,
                            java.util.Arrays.asList(imageFile), link, dealId, username).setVisible(true);
                });

                dealCard.add(gotoBtn);

                return dealCard;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private void deleteDeal(int dealId) {
        try (Connection conn = DBConnection.getConnection()) {
            // Delete from wishlist 
            String wishlistSql = "DELETE FROM wishlist WHERE deal_id=?";
            PreparedStatement wishlistStmt = conn.prepareStatement(wishlistSql);
            wishlistStmt.setInt(1, dealId);
            wishlistStmt.executeUpdate();

            // Delete the deal
            String sql = "DELETE FROM deals WHERE id=? AND username=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, dealId);
            stmt.setString(2, username);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
