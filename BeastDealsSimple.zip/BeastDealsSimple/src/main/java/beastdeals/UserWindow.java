package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UserWindow extends JFrame {
    private String username;

    public UserWindow(String username) {
        this.username = username;
        setTitle("Your Profile");
        setSize(420, 370);
        setLocationRelativeTo(null);

        Color bg = new Color(35, 39, 42);
        Color card = new Color(26, 27, 30);
        Color orange = new Color(255, 139, 44);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(bg);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(32, 24, 32, 24));

        // --- Profile Section ---
        JPanel profilePanel = new JPanel();
        profilePanel.setBackground(card);
        profilePanel.setMaximumSize(new Dimension(340, 80));
        profilePanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 70), 1, true),
                BorderFactory.createEmptyBorder(18, 26, 18, 26)
        ));

        JLabel avatar = new JLabel(username.substring(0,1).toUpperCase());
        avatar.setFont(new Font("Arial", Font.BOLD, 28));
        avatar.setForeground(Color.WHITE);
        avatar.setOpaque(true);
        avatar.setBackground(orange);
        avatar.setHorizontalAlignment(SwingConstants.CENTER);
        avatar.setPreferredSize(new Dimension(56, 56));
        avatar.setBorder(BorderFactory.createEmptyBorder(6,6,6,6));

        JLabel userLabel = new JLabel(username);
        userLabel.setFont(new Font("Arial", Font.BOLD, 23));
        userLabel.setForeground(Color.WHITE);
        userLabel.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 0));

        profilePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        profilePanel.add(avatar);
        profilePanel.add(userLabel);

        mainPanel.add(profilePanel);
        mainPanel.add(Box.createVerticalStrut(36));

        // --- My Wishlist Button ---
        JButton wishlistBtn = new JButton("   My Wishlist");
        wishlistBtn.setFont(new Font("Arial", Font.BOLD, 18));
        wishlistBtn.setBackground(card);
        wishlistBtn.setForeground(Color.WHITE);
        wishlistBtn.setFocusPainted(false);
        wishlistBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 70), 1, true),
                BorderFactory.createEmptyBorder(18, 32, 18, 32)
        ));
        wishlistBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        wishlistBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Wishlist icon
        ImageIcon icon1 = new ImageIcon("icons/wishlist.png");
        Image img1 = icon1.getImage().getScaledInstance(36, 36, Image.SCALE_SMOOTH);
        wishlistBtn.setIcon(new ImageIcon(img1));
        wishlistBtn.setHorizontalAlignment(SwingConstants.LEFT);

        wishlistBtn.addActionListener(e -> new WishlistWindow(username).setVisible(true));

        mainPanel.add(wishlistBtn);
        mainPanel.add(Box.createVerticalStrut(18));

        // --- Your Deals Button ---
        JButton yourDealsBtn = new JButton("   Your Deals");
        yourDealsBtn.setFont(new Font("Arial", Font.BOLD, 18));
        yourDealsBtn.setBackground(card);
        yourDealsBtn.setForeground(Color.WHITE);
        yourDealsBtn.setFocusPainted(false);
        yourDealsBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 70), 1, true),
                BorderFactory.createEmptyBorder(18, 32, 18, 32)
        ));
        yourDealsBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        yourDealsBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Your Deals icon
        ImageIcon icon2 = new ImageIcon("icons/your_deals.png");
        Image img2 = icon2.getImage().getScaledInstance(36, 36, Image.SCALE_SMOOTH);
        yourDealsBtn.setIcon(new ImageIcon(img2));
        yourDealsBtn.setHorizontalAlignment(SwingConstants.LEFT);

        yourDealsBtn.addActionListener(e -> new YourDealsWindow(username).setVisible(true)); // Implement this window

        mainPanel.add(yourDealsBtn);

        add(mainPanel);
    }
}
