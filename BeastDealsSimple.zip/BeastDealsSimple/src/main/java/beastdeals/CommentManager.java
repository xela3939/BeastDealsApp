/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.beastdeals;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CommentManager {
    public static List<String[]> getComments(int dealId) {
        List<String[]> comments = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT username, comment_text, comment_date FROM comments WHERE deal_id = ? ORDER BY comment_date ASC";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, dealId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String user = rs.getString("username");
                String text = rs.getString("comment_text");
                String date = rs.getString("comment_date");
                comments.add(new String[]{user, text, date});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return comments;
    }

    public static boolean addComment(int dealId, String username, String commentText) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO comments (deal_id, username, comment_text) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, dealId);
            stmt.setString(2, username);
            stmt.setString(3, commentText);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
