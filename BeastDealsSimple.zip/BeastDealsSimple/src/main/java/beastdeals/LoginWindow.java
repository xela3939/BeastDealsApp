package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginWindow extends JFrame {
    private JTextField userField;
    private JPasswordField passField;

    public LoginWindow() {
        setTitle("Login");
        setSize(420, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(new Color(35, 39, 42));

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(35, 39, 42));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 38, 20, 38));
        mainPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel heading = new JLabel("Welcome Back!");
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setForeground(new Color(255, 139, 44));
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);

        mainPanel.add(heading);
        mainPanel.add(Box.createVerticalStrut(18));

        JLabel userLbl = new JLabel("Username:");
        userLbl.setForeground(Color.WHITE);
        userLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(userLbl);

        mainPanel.add(Box.createVerticalStrut(2));
        userField = new JTextField();
        styleField(userField);
        mainPanel.add(centerPanel(userField));

        mainPanel.add(Box.createVerticalStrut(10));
        JLabel passLbl = new JLabel("Password:");
        passLbl.setForeground(Color.WHITE);
        passLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(passLbl);

        mainPanel.add(Box.createVerticalStrut(2));
        passField = new JPasswordField();
        styleField(passField);
        mainPanel.add(centerPanel(passField));

        mainPanel.add(Box.createVerticalStrut(20));

        // Login Button
        JButton loginBtn = new JButton();
        ImageIcon loginIcon = new ImageIcon("icons/login_b.png");
        Image loginImg = loginIcon.getImage().getScaledInstance(182, 48, Image.SCALE_SMOOTH);
        loginBtn.setIcon(new ImageIcon(loginImg));
        loginBtn.setBorder(null);
        loginBtn.setContentAreaFilled(false);
        loginBtn.setFocusPainted(false);
        loginBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        loginBtn.addActionListener(e -> handleLogin());
        mainPanel.add(loginBtn);

        mainPanel.add(Box.createVerticalStrut(14));

        JButton regBtn = new JButton("No account? Register");
        regBtn.setForeground(new Color(255, 139, 44));
        regBtn.setFont(new Font("Arial", Font.BOLD, 15));
        regBtn.setBackground(new Color(35, 39, 42));
        regBtn.setBorderPainted(false);
        regBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        regBtn.setFocusPainted(false);
        regBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        regBtn.addActionListener(e -> {
            new RegisterWindow().setVisible(true);
        });
        mainPanel.add(regBtn);

        wrapper.add(mainPanel); 

        setContentPane(wrapper);
    }

    private void styleField(JTextField field) {
        field.setBackground(new Color(60, 60, 70));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        field.setFont(new Font("Arial", Font.PLAIN, 17));
        field.setMaximumSize(new Dimension(230, 38));
        field.setPreferredSize(new Dimension(230, 38));
        field.setHorizontalAlignment(JTextField.CENTER);
    }

    private JPanel centerPanel(JComponent c) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        p.setBackground(new Color(35, 39, 42));
        p.add(c);
        return p;
    }

    private void handleLogin() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, password_hash FROM users WHERE username=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String dbPass = rs.getString("password_hash");
                int userId = rs.getInt("id");
                if (dbPass.equals(password)) { 
                    // login success
                    JOptionPane.showMessageDialog(this, "Login successful!");
                    dispose();
                    new MainWindow(username, userId).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Wrong password.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "User not found.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error connecting to DB.");
        }
    }
}
