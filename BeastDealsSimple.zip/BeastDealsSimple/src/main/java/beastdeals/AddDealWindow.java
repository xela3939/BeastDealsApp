package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.File;

public class AddDealWindow extends JFrame {
    private String username;
    private int userId;
    private JTextField titleField, priceField, expiryField, linkField;
    private JTextArea descArea;
    private JLabel[] imageLabels = new JLabel[8];
    private String[] imageFiles = new String[8];

    public AddDealWindow(String username, int userId) {
        this.username = username;
        this.userId = userId;

        setTitle("Add Deal");
        setSize(670, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(35, 39, 42));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 44, 30, 44));

        // Title
        JLabel heading = new JLabel("Add a New Deal");
        heading.setFont(new Font("Arial", Font.BOLD, 28));
        heading.setForeground(new Color(255, 139, 44));
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(heading);
        mainPanel.add(Box.createVerticalStrut(18));

        // Title field
        JLabel titleLbl = styledLabel("Title");
        mainPanel.add(titleLbl);
        titleField = new JTextField();
        styleField(titleField);
        mainPanel.add(titleField);

        // Description field
        mainPanel.add(Box.createVerticalStrut(12));
        JLabel descLbl = styledLabel("Description");
        mainPanel.add(descLbl);
        descArea = new JTextArea(4, 36);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        JScrollPane descScroll = new JScrollPane(descArea);
        descScroll.setPreferredSize(new Dimension(530, 82));
        descScroll.setMaximumSize(new Dimension(530, 110));
        styleArea(descArea);
        descScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(descScroll);

        // Price
        mainPanel.add(Box.createVerticalStrut(12));
        JLabel priceLbl = styledLabel("Price");
        mainPanel.add(priceLbl);
        priceField = new JTextField();
        styleField(priceField);
        mainPanel.add(priceField);

        // Expiry
        mainPanel.add(Box.createVerticalStrut(12));
        JLabel expiryLbl = styledLabel("Expiry Date (YYYY-MM-DD)");
        mainPanel.add(expiryLbl);
        expiryField = new JTextField();
        styleField(expiryField);
        mainPanel.add(expiryField);

        // DealLink
        mainPanel.add(Box.createVerticalStrut(12));
        JLabel linkLbl = styledLabel("Deal Link");
        mainPanel.add(linkLbl);
        linkField = new JTextField();
        styleField(linkField);
        mainPanel.add(linkField);

        // Images
        mainPanel.add(Box.createVerticalStrut(16));
        JLabel imgLbl = styledLabel("Deal Images (up to 8, click to add, right-click to remove):");
        mainPanel.add(imgLbl);

        JPanel imagesPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        imagesPanel.setBackground(new Color(35, 39, 42));
        imagesPanel.setMaximumSize(new Dimension(530, 170));
        imagesPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        for (int i = 0; i < 8; i++) {
            int idx = i;
            imageLabels[i] = new JLabel("+", SwingConstants.CENTER);
            imageLabels[i].setPreferredSize(new Dimension(70, 70));
            imageLabels[i].setOpaque(true);
            imageLabels[i].setBackground(new Color(60, 60, 70));
            imageLabels[i].setForeground(Color.WHITE);
            imageLabels[i].setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
            imageLabels[i].setFont(new Font("Arial", Font.BOLD, 32));
            imageLabels[i].setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            imageLabels[i].addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    if (SwingUtilities.isLeftMouseButton(e)) {
                        JFileChooser fc = new JFileChooser();
                        if (fc.showOpenDialog(AddDealWindow.this) == JFileChooser.APPROVE_OPTION) {
                            File file = fc.getSelectedFile();
                            imageFiles[idx] = file.getName();
                            ImageIcon icon = new ImageIcon(file.getAbsolutePath());
                            Image img = icon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
                            imageLabels[idx].setIcon(new ImageIcon(img));
                            imageLabels[idx].setText("");
                            
                            try {
                                File dest = new File("images/" + file.getName());
                                if (!dest.exists()) {
                                    java.nio.file.Files.copy(file.toPath(), dest.toPath());
                                }
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    } else if (SwingUtilities.isRightMouseButton(e)) {
                        imageFiles[idx] = null;
                        imageLabels[idx].setIcon(null);
                        imageLabels[idx].setText("+");
                    }
                }
            });
            imagesPanel.add(imageLabels[i]);
        }
        mainPanel.add(imagesPanel);

        // Submit Button
        mainPanel.add(Box.createVerticalStrut(26));
        JButton submitBtn = new JButton("Add Deal");
        submitBtn.setBackground(new Color(255, 139, 44));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFont(new Font("Arial", Font.BOLD, 20));
        submitBtn.setFocusPainted(false);
        submitBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        submitBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        submitBtn.setPreferredSize(new Dimension(170, 44));
        submitBtn.setMaximumSize(new Dimension(170, 44));
        submitBtn.addActionListener(e -> submitDeal());
        mainPanel.add(submitBtn);

        // Add scroll
        JScrollPane scrollPane = new JScrollPane(mainPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        setContentPane(scrollPane);
    }

    private JLabel styledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private void styleField(JTextField field) {
        field.setBackground(new Color(60, 60, 70));
        field.setForeground(Color.WHITE);
        field.setCaretColor(Color.WHITE);
        field.setBorder(BorderFactory.createEmptyBorder(9, 11, 9, 11));
        field.setFont(new Font("Arial", Font.PLAIN, 17));
        field.setMaximumSize(new Dimension(530, 38));
        field.setPreferredSize(new Dimension(530, 38));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    private void styleArea(JTextArea area) {
        area.setBackground(new Color(60, 60, 70));
        area.setForeground(Color.WHITE);
        area.setCaretColor(Color.WHITE);
        area.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        area.setFont(new Font("Arial", Font.PLAIN, 17));
    }

    private void submitDeal() {
        String title = titleField.getText().trim();
        String description = descArea.getText().trim();
        String price = priceField.getText().trim();
        String expiry = expiryField.getText().trim();
        String link = linkField.getText().trim();

        if (title.isEmpty() || description.isEmpty() || price.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all required fields!");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO deals (title, description, price, expiry_date, image1, image2, image3, image4, image5, image6, image7, image8, link, username) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setString(3, price);
            stmt.setString(4, expiry);
            for (int i = 0; i < 8; i++)
                stmt.setString(5 + i, imageFiles[i]);
            stmt.setString(13, link);
            stmt.setString(14, username);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Deal added!");
            dispose();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to add deal.");
        }
    }
}
