/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.beastdeals;

public class Deal {
    private String title;
    private double price;
    private String description;
    private String imagePath;
    private String link;

    public Deal(String title, double price, String description, String imagePath, String link) {
        this.title = title;
        this.price = price;
        this.description = description;
        this.imagePath = imagePath;
        this.link = link;
    }

    public String getTitle() {
        return title;
    }

    public double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getLink() {
        return link;
    }
}
