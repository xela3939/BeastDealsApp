package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class MainWindow extends JFrame {
    private JPanel dealsPanel;
    private String username;
    private int userId;

    public MainWindow(String username, int userId) {
        this.username = username;
        this.userId = userId;

        setTitle("BeastDeals - Deal Feed");
        setSize(1080, 730);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //  Top Navigation 
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(35, 39, 42));
        topPanel.setBorder(BorderFactory.createEmptyBorder(7, 14, 7, 16));

        // Left: Add Deal button
        JButton addDealBtn = new JButton();
        ImageIcon addIcon = new ImageIcon("icons/add_deal.png");
        addDealBtn.setIcon(new ImageIcon(addIcon.getImage().getScaledInstance(38, 38, Image.SCALE_SMOOTH)));
        addDealBtn.setBackground(new Color(60, 60, 70));
        addDealBtn.setBorderPainted(false);
        addDealBtn.setFocusPainted(false);
        addDealBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        topPanel.add(addDealBtn, BorderLayout.WEST);

        // Right: User + Logout
        JPanel userButtons = new JPanel();
        userButtons.setOpaque(false);

        JButton userBtn = new JButton();
        ImageIcon userIcon = new ImageIcon("icons/user_b.png");
        userBtn.setIcon(new ImageIcon(userIcon.getImage().getScaledInstance(36, 36, Image.SCALE_SMOOTH)));
        userBtn.setBackground(new Color(60, 60, 70));
        userBtn.setBorderPainted(false);
        userBtn.setFocusPainted(false);
        userBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JButton logoutBtn = new JButton();
        ImageIcon logoutIcon = new ImageIcon("icons/logout_main.png");
        logoutBtn.setIcon(new ImageIcon(logoutIcon.getImage().getScaledInstance(36, 36, Image.SCALE_SMOOTH)));
        logoutBtn.setBackground(new Color(60, 60, 70));
        logoutBtn.setBorderPainted(false);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        userButtons.add(userBtn);
        userButtons.add(Box.createHorizontalStrut(12));
        userButtons.add(logoutBtn);
        topPanel.add(userButtons, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // --- Deal Feed Panel ---
        dealsPanel = new JPanel();
        dealsPanel.setLayout(new BoxLayout(dealsPanel, BoxLayout.Y_AXIS));
        dealsPanel.setBackground(new Color(45, 47, 50));
        JScrollPane scrollPane = new JScrollPane(dealsPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(32); // scroll speed
        add(scrollPane, BorderLayout.CENTER);

        // --- Action Listeners ---
        addDealBtn.addActionListener(e -> {
            AddDealWindow addDealWindow = new AddDealWindow(username, userId);
            addDealWindow.setVisible(true);
            addDealWindow.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent e) {
                    loadDeals();
                }
            });
        });
        userBtn.addActionListener(e -> new UserWindow(username).setVisible(true));
        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginWindow().setVisible(true);
        });

        loadDeals();
    }

    private void loadDeals() {
        dealsPanel.removeAll();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, title, description, price, expiry_date, image1, image2, image3, image4, image5, image6, image7, image8, username, link FROM deals ORDER BY id DESC";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int dealId = rs.getInt("id");
                String title = rs.getString("title");
                String description = rs.getString("description");
                String price = rs.getString("price");
                String expires = rs.getString("expiry_date");
                String addedBy = rs.getString("username");
                String link = rs.getString("link");

                // all images
                List<String> images = new ArrayList<>();
                for (int i = 1; i <= 8; i++) {
                    String img = rs.getString("image" + i);
                    if (img != null && !img.isEmpty()) images.add(img);
                }
                String imageFile = images.size() > 0 ? images.get(0) : null;

                // Card panel 
                JPanel dealCard = new JPanel(new GridBagLayout());
                dealCard.setBackground(new Color(35, 39, 42));
                dealCard.setBorder(BorderFactory.createEmptyBorder(12, 26, 12, 26));
                dealCard.setMaximumSize(new Dimension(920, 130));
                dealCard.setPreferredSize(new Dimension(900, 120));

                GridBagConstraints c = new GridBagConstraints();
                c.insets = new Insets(0, 0, 0, 0);
                c.gridy = 0;

                //  Photo 
                c.gridx = 0;
                c.anchor = GridBagConstraints.WEST;
                JLabel imageLabel;
                if (imageFile != null) {
                    String imagePath = "images/" + imageFile;
                    ImageIcon icon = new ImageIcon(imagePath);
                    Image img = icon.getImage().getScaledInstance(88, 88, Image.SCALE_SMOOTH);
                    imageLabel = new JLabel(new ImageIcon(img));
                    imageLabel.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 70), 2));
                } else {
                    imageLabel = new JLabel("No Image");
                    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                    imageLabel.setPreferredSize(new Dimension(88, 88));
                    imageLabel.setForeground(Color.LIGHT_GRAY);
                    imageLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                }
                imageLabel.setPreferredSize(new Dimension(88, 88));
                imageLabel.setOpaque(false);
                dealCard.add(imageLabel, c);

                // Deal Info (title, price, expires, added by) 
                c.gridx = 1;
                c.weightx = 1.0;
                c.anchor = GridBagConstraints.WEST;
                JPanel infoPanel = new JPanel();
                infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
                infoPanel.setBackground(new Color(35, 39, 42));
                infoPanel.setBorder(BorderFactory.createEmptyBorder(0, 18, 0, 0));

                JLabel titleLabel = new JLabel(title);
                titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
                titleLabel.setForeground(Color.WHITE);
                infoPanel.add(titleLabel);

                JPanel priceAndMeta = new JPanel();
                priceAndMeta.setLayout(new BoxLayout(priceAndMeta, BoxLayout.X_AXIS));
                priceAndMeta.setBackground(new Color(35, 39, 42));

                JLabel priceLabel = new JLabel("£" + price);
                priceLabel.setFont(new Font("Arial", Font.BOLD, 18));
                priceLabel.setForeground(new Color(255, 139, 44));
                priceAndMeta.add(priceLabel);

                priceAndMeta.add(Box.createHorizontalStrut(18));

                JLabel expiresLabel = new JLabel("Expires: " + expires);
                expiresLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                expiresLabel.setForeground(new Color(200, 200, 200));
                priceAndMeta.add(expiresLabel);

                priceAndMeta.add(Box.createHorizontalStrut(18));

                JLabel userLabel = new JLabel("Added by: " + (addedBy != null ? addedBy : "unknown"));
                userLabel.setFont(new Font("Arial", Font.PLAIN, 13));
                userLabel.setForeground(new Color(160, 160, 160));
                priceAndMeta.add(userLabel);

                infoPanel.add(priceAndMeta);

                dealCard.add(infoPanel, c);

                //  Buttons (right) 
                c.gridx = 2;
                c.weightx = 0;
                c.anchor = GridBagConstraints.EAST;
                JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 0, 8));
                buttonPanel.setBackground(new Color(35, 39, 42));

                // "View" Button 
                JButton viewBtn = new JButton("View");
                viewBtn.setBackground(new Color(255, 139, 44));
                viewBtn.setForeground(Color.WHITE);
                viewBtn.setFont(new Font("Arial", Font.BOLD, 14));
                viewBtn.setFocusPainted(false);
                viewBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                viewBtn.setPreferredSize(new Dimension(84, 32));
                
                viewBtn.addActionListener(e -> {
                    new DealDetailWindow(title, description, price, expires, images, link, dealId, username).setVisible(true);
                });

                // "Save" Button 
                JButton saveBtn = new JButton("Save");
                saveBtn.setBackground(new Color(60, 60, 70));
                saveBtn.setForeground(Color.WHITE);
                saveBtn.setFont(new Font("Arial", Font.BOLD, 14));
                saveBtn.setFocusPainted(false);
                saveBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                saveBtn.setPreferredSize(new Dimension(84, 32));
                saveBtn.addActionListener(e -> {
                    if (WishlistManager.addToWishlist(username, dealId)) {
                        JOptionPane.showMessageDialog(this, "✅ Added to wishlist!");
                    } else {
                        int status = WishlistManager.statusLastSave;
                        String msg = "❌ Failed to save.";
                        if (status == 1) msg = "❌ Already in wishlist!";
                        if (status == 2) msg = "❌ Database error. Try again.";
                        JOptionPane.showMessageDialog(this, msg);
                    }
                });

                buttonPanel.add(viewBtn);
                buttonPanel.add(saveBtn);

                dealCard.add(buttonPanel, c);

                dealsPanel.add(dealCard);
                dealsPanel.add(Box.createVerticalStrut(14));
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "❌ Failed to load deals.");
        }
        dealsPanel.revalidate();
        dealsPanel.repaint();
    }
}
