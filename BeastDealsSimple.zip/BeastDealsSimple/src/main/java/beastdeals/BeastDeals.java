package main.java.beastdeals;

import javax.swing.SwingUtilities;

public class BeastDeals {
    public static void main(String[] args) {
        new LoginWindow().setVisible(true);
    }
}
