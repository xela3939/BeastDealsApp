/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.beastdeals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DealDatabase {
    public static boolean saveDeal(Deal deal) {
        try (Connection conn = DBConnection.getConnection()) {
            if (conn == null) {
                System.out.println("❌ Could not connect to database.");
                return false;
            }

            String sql = "INSERT INTO deals (title, price, description, image_path, link) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, deal.getTitle());
            stmt.setDouble(2, deal.getPrice());
            stmt.setString(3, deal.getDescription());
            stmt.setString(4, deal.getImagePath());
            stmt.setString(5, deal.getLink());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error saving deal: " + e.getMessage());
            return false;
        }
    }
}
