package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class CommentPanel extends JPanel {
    private JPanel commentsListPanel;
    private JTextField commentField;
    private int dealId;
    private String username;

    public CommentPanel(int dealId, String username) {
        this.dealId = dealId;
        this.username = username;
        setLayout(new BorderLayout());
        setBackground(new Color(26, 27, 30)); 

        // Comment input bar
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBackground(new Color(26, 27, 30));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        JLabel avatar = new JLabel(getInitial(username));
        avatar.setOpaque(true);
        avatar.setBackground(new Color(255, 139, 44));
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Arial", Font.BOLD, 18));
        avatar.setHorizontalAlignment(SwingConstants.CENTER);
        avatar.setPreferredSize(new Dimension(38, 38));
        avatar.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        inputPanel.add(avatar, BorderLayout.WEST);

        commentField = new JTextField();
        commentField.setFont(new Font("Arial", Font.PLAIN, 16));
        commentField.setBackground(new Color(40, 42, 44));
        commentField.setForeground(Color.WHITE);
        commentField.setCaretColor(Color.WHITE);
        commentField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(60, 60, 70), 1, true),
                BorderFactory.createEmptyBorder(8, 14, 8, 14)
        ));
        inputPanel.add(commentField, BorderLayout.CENTER);

        JButton postBtn = new JButton("Post");
        postBtn.setBackground(new Color(255, 139, 44));
        postBtn.setForeground(Color.WHITE);
        postBtn.setFont(new Font("Arial", Font.BOLD, 15));
        postBtn.setFocusPainted(false);
        postBtn.setBorder(BorderFactory.createEmptyBorder(8, 28, 8, 28));
        postBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        postBtn.addActionListener(e -> {
            String text = commentField.getText().trim();
            if (text.length() < 2) {
                JOptionPane.showMessageDialog(this, "Write a longer comment!");
                return;
            }
            if (CommentManager.addComment(dealId, username, text)) {
                commentField.setText("");
                loadComments();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to post comment.");
            }
        });
        inputPanel.add(postBtn, BorderLayout.EAST);

        add(inputPanel, BorderLayout.NORTH);

        //  Comments list
        commentsListPanel = new JPanel();
        commentsListPanel.setLayout(new BoxLayout(commentsListPanel, BoxLayout.Y_AXIS));
        commentsListPanel.setBackground(new Color(26, 27, 30));

        JScrollPane commentScroll = new JScrollPane(commentsListPanel);
        commentScroll.setBorder(null);
        commentScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        commentScroll.getVerticalScrollBar().setUnitIncrement(18); 
        commentScroll.setPreferredSize(new Dimension(800, 220));   
        commentScroll.setMaximumSize(new Dimension(2000, 340));

        add(commentScroll, BorderLayout.CENTER);

        loadComments();
    }

    private void loadComments() {
        commentsListPanel.removeAll();
        List<String[]> comments = CommentManager.getComments(dealId);

        if (comments.isEmpty()) {
            JLabel none = new JLabel("No comments yet.");
            none.setForeground(Color.LIGHT_GRAY);
            none.setFont(new Font("Arial", Font.ITALIC, 15));
            none.setBorder(BorderFactory.createEmptyBorder(16, 32, 0, 0));
            commentsListPanel.add(none);
        } else {
            for (String[] c : comments) {
                commentsListPanel.add(buildCommentBox(c[0], c[1], c[2]));
                commentsListPanel.add(Box.createVerticalStrut(10));
            }
        }
        commentsListPanel.revalidate();
        commentsListPanel.repaint();
    }

    private JPanel buildCommentBox(String user, String text, String date) {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(new Color(40, 42, 44));
        outer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(55, 55, 60), 1, true),
                BorderFactory.createEmptyBorder(10, 13, 10, 13)
        ));
        outer.setMaximumSize(new Dimension(Integer.MAX_VALUE, 55)); 

        // Avatar
        JLabel avatar = new JLabel(getInitial(user));
        avatar.setOpaque(true);
        avatar.setBackground(new Color(255, 139, 44));
        avatar.setForeground(Color.WHITE);
        avatar.setFont(new Font("Arial", Font.BOLD, 16));
        avatar.setHorizontalAlignment(SwingConstants.CENTER);
        avatar.setPreferredSize(new Dimension(34, 34));
        outer.add(avatar, BorderLayout.WEST);

        // Center- Username/date/comment
        JPanel center = new JPanel();
        center.setOpaque(false);
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        JPanel userRow = new JPanel();
        userRow.setOpaque(false);
        userRow.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 0));
        JLabel userLabel = new JLabel(user);
        userLabel.setFont(new Font("Arial", Font.BOLD, 14));
        userLabel.setForeground(Color.WHITE);
        JLabel dateLabel = new JLabel(date.substring(0, Math.min(16, date.length())));
        dateLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        dateLabel.setForeground(new Color(150, 150, 150));
        userRow.add(userLabel);
        userRow.add(dateLabel);
        center.add(userRow);

        JLabel commentText = new JLabel("<html>" + escapeHtml(text) + "</html>");
        commentText.setFont(new Font("Arial", Font.PLAIN, 14));
        commentText.setForeground(Color.WHITE);
        commentText.setBorder(BorderFactory.createEmptyBorder(2, 0, 0, 0));
        center.add(commentText);

        outer.add(center, BorderLayout.CENTER);

        return outer;
    }

    private String getInitial(String name) {
        if (name == null || name.isEmpty()) return "U";
        return name.substring(0, 1).toUpperCase();
    }

    private String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;").replace("<", "&lt;")
                   .replace(">", "&gt;").replace("\"", "&quot;");
    }
}
