package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.List;

public class WishlistWindow extends JFrame {
    private JPanel wishlistPanel;
    private String username;

    public WishlistWindow(String username) {
        this.username = username;
        setTitle("My Wishlist");
        setSize(880, 620);
        setLocationRelativeTo(null);

        Color cardBg = new Color(26, 27, 30);
        Color darkBg = new Color(35, 39, 42);
        Color orange = new Color(255, 139, 44);
        Color borderGray = new Color(60, 60, 70);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(darkBg);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(22, 0, 22, 0));

        JLabel titleLabel = new JLabel("My Wishlist");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(24));

        wishlistPanel = new JPanel();
        wishlistPanel.setLayout(new BoxLayout(wishlistPanel, BoxLayout.Y_AXIS));
        wishlistPanel.setBackground(darkBg);

        JScrollPane scrollPane = new JScrollPane(wishlistPanel);
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(18);
        scrollPane.setPreferredSize(new Dimension(830, 480));

        mainPanel.add(scrollPane);
        add(mainPanel);

        loadWishlist();
    }

    
    
    private void loadWishlist() {
        wishlistPanel.removeAll();
        List<Integer> dealIds = WishlistManager.getWishlistDealIds(username);

        if (dealIds.isEmpty()) {
            JLabel noDeals = new JLabel("Your wishlist is empty.");
            noDeals.setFont(new Font("Arial", Font.ITALIC, 18));
            noDeals.setForeground(Color.LIGHT_GRAY);
            noDeals.setAlignmentX(Component.CENTER_ALIGNMENT);
            wishlistPanel.add(Box.createVerticalStrut(32));
            wishlistPanel.add(noDeals);
        } else {
            for (int dealId : dealIds) {
                JPanel dealPanel = getDealPanel(dealId);
                if (dealPanel != null) {
                    wishlistPanel.add(dealPanel);
                    wishlistPanel.add(Box.createVerticalStrut(16));
                }
            }
        }
        wishlistPanel.revalidate();
        wishlistPanel.repaint();
    }

    private JPanel getDealPanel(int dealId) {
        Color cardBg = new Color(26, 27, 30);
        Color borderGray = new Color(60, 60, 70);
        Color orange = new Color(255, 139, 44);

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, title, price, image1, description, expiry_date, link FROM deals WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, dealId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String title = rs.getString("title");
                String price = rs.getString("price");
                String imageFile = rs.getString("image1");
                String description = rs.getString("description");
                String expires = rs.getString("expiry_date");
                String link = rs.getString("link");

                JPanel dealCard = new JPanel();
                dealCard.setLayout(new BoxLayout(dealCard, BoxLayout.X_AXIS));
                dealCard.setBackground(cardBg);
                dealCard.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(borderGray, 1, true),
                        BorderFactory.createEmptyBorder(12, 16, 12, 16)
                ));
                dealCard.setMaximumSize(new Dimension(800, 120));
                dealCard.setAlignmentX(Component.LEFT_ALIGNMENT);

                // Remove from wishlist button (BIG LEFT)
                JButton removeBtn = new JButton();
                ImageIcon trashIcon = new ImageIcon("icons/recicle_bin.png");
                Image trashImg = trashIcon.getImage().getScaledInstance(38, 38, Image.SCALE_SMOOTH);
                removeBtn.setIcon(new ImageIcon(trashImg));
                removeBtn.setToolTipText("Remove from wishlist");
                removeBtn.setBackground(new Color(45, 47, 52));
                removeBtn.setFocusPainted(false);
                removeBtn.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
                removeBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                removeBtn.setPreferredSize(new Dimension(54, 54));
                removeBtn.setMaximumSize(new Dimension(54, 54));
                removeBtn.addActionListener(e -> {
                    if (WishlistManager.removeFromWishlist(username, dealId)) {
                        JOptionPane.showMessageDialog(this, "Removed from wishlist.");
                        loadWishlist();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to remove.");
                    }
                });

                dealCard.add(removeBtn);
                dealCard.add(Box.createHorizontalStrut(22));

                // Image
                JLabel imageLabel;
                if (imageFile != null && !imageFile.isEmpty()) {
                    String imagePath = "images/" + imageFile;
                    ImageIcon icon = new ImageIcon(imagePath);
                    Image img = icon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
                    imageLabel = new JLabel(new ImageIcon(img));
                } else {
                    imageLabel = new JLabel("No Image");
                    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                    imageLabel.setPreferredSize(new Dimension(80, 80));
                }
                dealCard.add(imageLabel);
                dealCard.add(Box.createHorizontalStrut(22));

                // Title + Price
                JPanel infoPanel = new JPanel();
                infoPanel.setOpaque(false);
                infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
                infoPanel.setMaximumSize(new Dimension(420, 90));

                JLabel titleLabel = new JLabel(title);
                titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
                titleLabel.setForeground(Color.WHITE);
                infoPanel.add(titleLabel);

                JLabel priceLabel = new JLabel("£" + price);
                priceLabel.setFont(new Font("Arial", Font.BOLD, 16));
                priceLabel.setForeground(orange);
                infoPanel.add(Box.createVerticalStrut(4));
                infoPanel.add(priceLabel);

                dealCard.add(infoPanel);
                dealCard.add(Box.createHorizontalGlue());

                // Go to deal button
                JButton gotoBtn = new JButton("Go to Deal");
                gotoBtn.setBackground(orange);
                gotoBtn.setForeground(Color.WHITE);
                gotoBtn.setFocusPainted(false);
                gotoBtn.setFont(new Font("Arial", Font.BOLD, 14));
                gotoBtn.setBorder(BorderFactory.createEmptyBorder(10, 26, 10, 26));
                gotoBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                gotoBtn.setAlignmentY(Component.CENTER_ALIGNMENT);

                gotoBtn.addActionListener(e -> {
                    new DealDetailWindow(title, description, price, expires,
                            java.util.Arrays.asList(imageFile), link, dealId, username).setVisible(true);
                });

                dealCard.add(gotoBtn);

                return dealCard;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
