package main.java.beastdeals;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.util.List;
import java.io.File;

public class DealDetailWindow extends JFrame {
    private JLabel mainImageLabel;
    private List<String> imageFiles;
    private int selectedImageIndex = 0;
    private int votes = 10; 

    // Icon paths
    private static final String ICONS_DIR = "icons" + File.separator;
    private static final String ICON_UP = ICONS_DIR + "arrow_up.png";
    private static final String ICON_DOWN = ICONS_DIR + "arrow_down.png";
    private static final String ICON_HEART = ICONS_DIR + "heart.png";
    private static final String ICON_DESCRIPTION = ICONS_DIR + "description_icon.png";
    private static final String ICON_COMMENTS = ICONS_DIR + "comments_icon.png";

    public DealDetailWindow(String title, String description, String price, String expires,
                            List<String> imageFiles, String link, int dealId, String username) {
        this.imageFiles = imageFiles;
        setTitle("Deal Details");
        setSize(1350, 950);
        setLocationRelativeTo(null);

        // COLOURS 
        Color darkBg = new Color(35, 39, 42);
        Color cardBg = new Color(26, 27, 30);
        Color orange = new Color(255, 139, 44);
        Color borderGray = new Color(60, 60, 70);
        Color midGray = new Color(170, 170, 170);

        // ERTICAL STACK 
        JPanel mainContent = new JPanel();
        mainContent.setLayout(new BoxLayout(mainContent, BoxLayout.Y_AXIS));
        mainContent.setBackground(darkBg);
        mainContent.setBorder(BorderFactory.createEmptyBorder(24, 0, 24, 0));

        int cardWidth = 950;

        // TOP: Images and Info
        JPanel topRow = new JPanel();
        topRow.setLayout(new BoxLayout(topRow, BoxLayout.X_AXIS));
        topRow.setOpaque(false);
        topRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        // IMAGES COLUMN 
        JPanel imagesPanel = new JPanel();
        imagesPanel.setLayout(new BoxLayout(imagesPanel, BoxLayout.X_AXIS));
        imagesPanel.setBackground(darkBg);

        // Main Image
        mainImageLabel = new JLabel();
        mainImageLabel.setPreferredSize(new Dimension(330, 330));
        mainImageLabel.setMinimumSize(new Dimension(330, 330));
        mainImageLabel.setMaximumSize(new Dimension(330, 330));
        mainImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainImageLabel.setBorder(BorderFactory.createLineBorder(borderGray, 3, true));
        mainImageLabel.setOpaque(true);
        mainImageLabel.setBackground(cardBg);
        updateMainImage();

        // Thumbnails to the right 
        JPanel thumbsPanel = new JPanel();
        thumbsPanel.setLayout(new BoxLayout(thumbsPanel, BoxLayout.Y_AXIS));
        thumbsPanel.setBackground(darkBg);
        if (imageFiles != null && imageFiles.size() > 1) {
            for (int i = 0; i < imageFiles.size(); i++) {
                String img = imageFiles.get(i);
                JLabel thumb = new JLabel(new ImageIcon(new ImageIcon("images/" + img)
                        .getImage().getScaledInstance(54, 54, Image.SCALE_SMOOTH)));
                thumb.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                thumb.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(i == selectedImageIndex ? orange : borderGray, 2, true),
                        BorderFactory.createEmptyBorder(2, 2, 2, 2)
                ));
                int idx = i;
                thumb.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        selectedImageIndex = idx;
                        updateMainImage();
                        SwingUtilities.invokeLater(() -> thumbsPanel.repaint());
                    }
                });
                thumbsPanel.add(thumb);
                thumbsPanel.add(Box.createVerticalStrut(10));
            }
        }

        imagesPanel.add(mainImageLabel);
        imagesPanel.add(Box.createHorizontalStrut(14));
        imagesPanel.add(thumbsPanel);
        imagesPanel.setMaximumSize(new Dimension(420, 340));
        imagesPanel.setAlignmentY(Component.TOP_ALIGNMENT);

        topRow.add(Box.createHorizontalStrut(30));
        topRow.add(imagesPanel);
        topRow.add(Box.createHorizontalStrut(38));

        // INFO CARD 
        JPanel infoCard = new JPanel();
        infoCard.setBackground(cardBg);
        infoCard.setLayout(new BoxLayout(infoCard, BoxLayout.Y_AXIS));
        infoCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderGray, 1, true),
            BorderFactory.createEmptyBorder(20, 32, 20, 32)
        ));
        infoCard.setAlignmentY(Component.TOP_ALIGNMENT);
        infoCard.setMaximumSize(new Dimension(700, 320));
        infoCard.setPreferredSize(new Dimension(650, 270));

        //  FIRST ROW: VOTING AND SAVE 
        JPanel voteSaveRow = new JPanel();
        voteSaveRow.setOpaque(false);
        voteSaveRow.setLayout(new BoxLayout(voteSaveRow, BoxLayout.X_AXIS));
        voteSaveRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton upvoteBtn = new JButton(new ImageIcon(ICON_UP));
        upvoteBtn.setBackground(cardBg);
        upvoteBtn.setBorderPainted(false);
        upvoteBtn.setFocusPainted(false);
        upvoteBtn.setContentAreaFilled(false);
        upvoteBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        upvoteBtn.setPreferredSize(new Dimension(50, 50));
        upvoteBtn.setMaximumSize(new Dimension(50, 50));

        JLabel votesLabel = new JLabel(String.valueOf(votes), SwingConstants.CENTER);
        votesLabel.setFont(new Font("Arial", Font.BOLD, 30));
        votesLabel.setForeground(orange);
        votesLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JButton downvoteBtn = new JButton(new ImageIcon(ICON_DOWN));
        downvoteBtn.setBackground(cardBg);
        downvoteBtn.setBorderPainted(false);
        downvoteBtn.setFocusPainted(false);
        downvoteBtn.setContentAreaFilled(false);
        downvoteBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        downvoteBtn.setPreferredSize(new Dimension(50, 50));
        downvoteBtn.setMaximumSize(new Dimension(50, 50));

        upvoteBtn.addActionListener(e -> {
            votes++;
            votesLabel.setText(String.valueOf(votes));
        });
        downvoteBtn.addActionListener(e -> {
            votes--;
            votesLabel.setText(String.valueOf(votes));
        });

        voteSaveRow.add(upvoteBtn);
        voteSaveRow.add(votesLabel);
        voteSaveRow.add(downvoteBtn);
        voteSaveRow.add(Box.createHorizontalGlue());

        JButton saveBtn = new JButton("Save", new ImageIcon(ICON_HEART));
        saveBtn.setHorizontalTextPosition(SwingConstants.RIGHT);
        saveBtn.setIconTextGap(12);
        saveBtn.setBackground(orange);
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFont(new Font("Arial", Font.BOLD, 21));
        saveBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        saveBtn.setFocusPainted(false);
        saveBtn.setPreferredSize(new Dimension(180, 54));
        saveBtn.setMaximumSize(new Dimension(180, 54));
        saveBtn.addActionListener(e -> {
            if (WishlistManager.addToWishlist(username, dealId)) {
                JOptionPane.showMessageDialog(this, "✅ Added to wishlist!");
            } else {
                int status = WishlistManager.statusLastSave;
                String msg = "❌ Failed to save.";
                if (status == 1) msg = "❌ Already in wishlist!";
                if (status == 2) msg = "❌ Database error. Try again.";
                JOptionPane.showMessageDialog(this, msg);
            }
        });
        voteSaveRow.add(saveBtn);

        infoCard.add(voteSaveRow);
        infoCard.add(Box.createVerticalStrut(18));

        //  SECOND ROW: TITLE
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoCard.add(titleLabel);

        infoCard.add(Box.createVerticalStrut(14));

        // Expires
        JLabel postedLabel = new JLabel("Expires: " + expires);
        postedLabel.setForeground(midGray);
        postedLabel.setFont(new Font("Arial", Font.PLAIN, 19));
        postedLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoCard.add(postedLabel);

        // Price
        JLabel priceLabel = new JLabel("£" + price);
        priceLabel.setFont(new Font("Arial", Font.BOLD, 32));
        priceLabel.setForeground(orange);
        priceLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoCard.add(priceLabel);

        infoCard.add(Box.createVerticalStrut(18));

        //Get Deal button
        JButton getDealBtn = new JButton("Get deal");
        getDealBtn.setBackground(orange);
        getDealBtn.setForeground(Color.WHITE);
        getDealBtn.setFont(new Font("Arial", Font.BOLD, 24));
        getDealBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        getDealBtn.setFocusPainted(false);
        getDealBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        getDealBtn.setPreferredSize(new Dimension(240, 62));
        getDealBtn.setMaximumSize(new Dimension(240, 62));
        getDealBtn.addActionListener(e -> {
            try {
                String realLink = link;
                if (realLink != null && !realLink.toLowerCase().startsWith("http")) {
                    realLink = "https://" + realLink;
                }
                Desktop.getDesktop().browse(new URI(realLink));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Cannot open link");
            }
        });
        infoCard.add(Box.createVerticalStrut(8));
        infoCard.add(getDealBtn);

        topRow.add(infoCard);
        topRow.add(Box.createHorizontalGlue());

        mainContent.add(topRow);
        mainContent.add(Box.createVerticalStrut(18));

        //  2. DESCRIPTION 
        JPanel descRow = new JPanel();
        descRow.setLayout(new BoxLayout(descRow, BoxLayout.X_AXIS));
        descRow.setBackground(cardBg);
        descRow.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderGray, 1, true),
                BorderFactory.createEmptyBorder(14, 28, 14, 28)
        ));
        descRow.setMaximumSize(new Dimension(cardWidth, 220));
        descRow.setPreferredSize(new Dimension(cardWidth, 220));
        descRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Icon
        JLabel descIcon = new JLabel(new ImageIcon(new ImageIcon(ICON_DESCRIPTION).getImage().getScaledInstance(34, 34, Image.SCALE_SMOOTH)));
        descIcon.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        descRow.add(descIcon);

        // Scrollable description area
        JTextArea descArea = new JTextArea(description);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setEditable(false);
        descArea.setFont(new Font("Arial", Font.PLAIN, 18));
        descArea.setForeground(Color.WHITE);
        descArea.setBackground(cardBg);
        descArea.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 6));
        descArea.setCaretPosition(0);

        JScrollPane descScroll = new JScrollPane(descArea);
        descScroll.setBorder(null);
        descScroll.setPreferredSize(new Dimension(cardWidth - 60, 180));
        descScroll.setMaximumSize(new Dimension(cardWidth - 60, 180));
        descScroll.getVerticalScrollBar().setUnitIncrement(18);
        descRow.add(descScroll);

        mainContent.add(descRow);
        mainContent.add(Box.createVerticalStrut(16));

        //  3. COMMENTS 
        JPanel commentsRow = new JPanel();
        commentsRow.setLayout(new BoxLayout(commentsRow, BoxLayout.X_AXIS));
        commentsRow.setBackground(cardBg);
        commentsRow.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderGray, 1, true),
                BorderFactory.createEmptyBorder(14, 28, 14, 28)
        ));
        commentsRow.setMaximumSize(new Dimension(cardWidth, 440));
        commentsRow.setPreferredSize(new Dimension(cardWidth, 440));
        commentsRow.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Comments icon
        JLabel commentsIcon = new JLabel(new ImageIcon(new ImageIcon(ICON_COMMENTS).getImage().getScaledInstance(34, 34, Image.SCALE_SMOOTH)));
        commentsIcon.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        commentsRow.add(commentsIcon);

        // Scrollable comments panel
        JScrollPane commentsScroll = new JScrollPane(new CommentPanel(dealId, username));
        commentsScroll.setBorder(null);
        commentsScroll.setPreferredSize(new Dimension(cardWidth - 60, 400));
        commentsScroll.setMaximumSize(new Dimension(cardWidth - 60, 400));
        commentsScroll.getVerticalScrollBar().setUnitIncrement(16);
        commentsRow.add(commentsScroll);

        mainContent.add(commentsRow);

        //  MAIN PAGE SCROLL 
        JScrollPane scrollPane = new JScrollPane(mainContent);
        scrollPane.setBorder(null);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getVerticalScrollBar().setUnitIncrement(32); // Scroll speed
        setContentPane(scrollPane);
    }

    private void updateMainImage() {
        if (imageFiles != null && !imageFiles.isEmpty()) {
            String mainImg = imageFiles.get(selectedImageIndex);
            ImageIcon icon = new ImageIcon("images/" + mainImg);
            Image img = icon.getImage().getScaledInstance(330, 330, Image.SCALE_SMOOTH);
            mainImageLabel.setIcon(new ImageIcon(img));
            mainImageLabel.setText("");
        } else {
            mainImageLabel.setIcon(null);
            mainImageLabel.setText("No Image");
        }
    }
}
