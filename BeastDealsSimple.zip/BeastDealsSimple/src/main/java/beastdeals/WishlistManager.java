package main.java.beastdeals;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class WishlistManager {
    
    public static int statusLastSave = 0;

    public static boolean addToWishlist(String username, int dealId) {
        statusLastSave = 0;
        if (username == null || username.isEmpty() || dealId <= 0) return false;
        try (Connection conn = DBConnection.getConnection()) {
            String check = "SELECT id FROM wishlist WHERE username=? AND deal_id=?";
            PreparedStatement checkStmt = conn.prepareStatement(check);
            checkStmt.setString(1, username);
            checkStmt.setInt(2, dealId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                statusLastSave = 1;
                return false;
            }
            String sql = "INSERT INTO wishlist (username, deal_id) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setInt(2, dealId);
            stmt.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            statusLastSave = 2;
            return false;
        }
    }

    public static boolean removeFromWishlist(String username, int dealId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM wishlist WHERE username=? AND deal_id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setInt(2, dealId);
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Integer> getWishlistDealIds(String username) {
        List<Integer> dealIds = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT deal_id FROM wishlist WHERE username=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                dealIds.add(rs.getInt("deal_id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dealIds;
    }

    public static boolean isInWishlist(String username, int dealId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id FROM wishlist WHERE username=? AND deal_id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setInt(2, dealId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
