package main.java.beastdeals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DealManager {
    public static boolean deleteDeal(int dealId, String username) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "DELETE FROM deals WHERE id = ? AND posted_by = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, dealId);
            stmt.setString(2, username);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.out.println("Error deleting deal: " + e.getMessage());
            return false;
        }
    }
}
